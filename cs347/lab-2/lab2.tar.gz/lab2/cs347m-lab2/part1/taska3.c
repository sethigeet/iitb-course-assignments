#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {
    pid_t pid = fork();

    if (pid == 0) {
        // Child Process (Process B)

        // Read num_a from parent
        

    } else {
        // Parent Process (Process A)

        // Send num_a to child
        
    }

    return 0;
}
