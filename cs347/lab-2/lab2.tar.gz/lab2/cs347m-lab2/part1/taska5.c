#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main(int argc, char *argv[]) {
    if (n > 0) {
        // Fork to create child
        pid = fork();
        if (pid < 0) {
            
            
        } else if (pid == 0) {
            // Child process: recursively execute the program with n-1

        } else {
            // Parent process: wait for child to terminate

        }
    }
    return 0;
}