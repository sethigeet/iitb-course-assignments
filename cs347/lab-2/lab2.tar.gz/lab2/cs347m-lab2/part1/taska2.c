#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <string.h>

int main() {
    char program[100]; // Buffer for program name

    while (1) {
        // Print prompt and read program name
        printf("Enter program: ");
        
    }

    return 0;
}