"""
Student evaluation script
Compares student's KV caching implementation against reference outputs
"""
from contextlib import nullcontext
import torch
import tiktoken
from model import GPT
import time
import json
import os

init_from = 'gpt2' 
device = 'cpu' 
dtype = 'float32'
compile = False
reference_file = 'reference_outputs.json'

TIME_TOLERANCE = 0.20  
TEXT_MATCH_REQUIRED = True 

# -----------------------------------------------------------------------------

def load_reference_data(filename):
    if not os.path.exists(filename):
        raise FileNotFoundError(f"Reference file not found: {filename}")
    
    with open(filename, 'r') as f:
        return json.load(f)

def generate_with_kv_cache(model, prompt, max_new_tokens, encode, decode, device, ctx, seed):
    start_ids = encode(prompt)
    x = torch.tensor(start_ids, dtype=torch.long, device=device)[None, ...]
    
    torch.manual_seed(seed) 
    
    with torch.no_grad():
        with ctx:
            start_time = time.perf_counter()
            output = model.generate(x, max_new_tokens, enable_kv_caching=True)
            end_time = time.perf_counter()
    
    time_taken = end_time - start_time
    output_text = decode(output[0].tolist())
    
    return {
        'output_text': output_text,
        'time_taken': time_taken,
        'tokens_generated': len(output[0].tolist())
    }

def compare_outputs(student_result, reference_result):
    text_match = student_result['output_text'] == reference_result['output_text']
    time_ratio = reference_result['time_taken'] / student_result['time_taken'] if student_result['time_taken'] > 0 else 0.0
    
    tokens_match = student_result['tokens_generated'] == reference_result['tokens_generated']
    
    return {
        'text_match': text_match,
        'speedup': time_ratio,
        'tokens_match': tokens_match,
        'passed': text_match and tokens_match
    }


print("="*80)
print("KV CACHING EVALUATION")
print("="*80)

print(f"\nLoading reference data from: {reference_file}")
reference_data = load_reference_data(reference_file)
seed = reference_data['config']['seed']

print(f"Configuration:")
print(f"  Model: {reference_data['config']['model']}")
print(f"  Seed: {seed}")
print(f"  Test cases: {len(reference_data['test_cases'])}")

torch.manual_seed(seed)
if 'cuda' in device:
    torch.cuda.manual_seed(seed)
    torch.backends.cuda.matmul.allow_tf32 = True
    torch.backends.cudnn.allow_tf32 = True

device_type = 'cuda' if 'cuda' in device else 'cpu'
ptdtype = {'float32': torch.float32, 'bfloat16': torch.bfloat16, 'float16': torch.float16}[dtype]
ctx = nullcontext() if device_type == 'cpu' else torch.amp.autocast(device_type=device_type, dtype=ptdtype)

print(f"\nLoading model: {init_from}")
model = GPT.from_pretrained(init_from, dict(dropout=0.0))
model.eval()
model.to(device)

if compile:
    print("Compiling model...")
    model = torch.compile(model)

enc = tiktoken.get_encoding("gpt2")
encode = lambda s: enc.encode(s, allowed_special={"<|endoftext|>"})
decode = lambda l: enc.decode(l)

print("\n" + "="*80)
print("RUNNING TESTS")
print("="*80)

results_summary = {
    'total_tests': len(reference_data['test_cases']),
    'passed': 0,
    'failed': 0,
    'test_results': []
}

performance_passed = True

for ref_test in reference_data['test_cases']:
    test_id = ref_test['test_id']
    prompt = ref_test['prompt']
    max_tokens = ref_test['max_tokens']
    
    print(f"\n{'='*80}")
    print(f"Test Case {test_id}")
    print(f"Prompt: '{prompt}'")
    print(f"Max tokens: {max_tokens}")
    print(f"{'='*80}")
    
    try:
        student_result = generate_with_kv_cache(
            model, prompt, max_tokens, encode, decode, device, ctx, seed
        )
        
        comparison = compare_outputs(student_result, ref_test)
        
        test_result = {
            'test_id': test_id,
            'prompt': prompt,
            'passed': comparison['passed'],
            'text_match': comparison['text_match'],
            'tokens_match': comparison['tokens_match'],
            'speedup': comparison['speedup'],
        }
        
        results_summary['test_results'].append(test_result)
        
        if comparison['passed']:
            results_summary['passed'] += 1
            status = "✓ PASSED"
        else:
            results_summary['failed'] += 1
            status = "✗ FAILED"
        
        print(f"\n{status}")
        print(f"\nResults:")
        print(f"  Text Match:        {'✓' if comparison['text_match'] else '✗'} {comparison['text_match']}")
        print(f"  Tokens Match:      {'✓' if comparison['tokens_match'] else '✗'} {comparison['tokens_match']}")
        print(f"\nTiming:")
        print(f"  Reference time:    {ref_test['time_taken']:.4f}s")
        print(f"  Student time:      {student_result['time_taken']:.4f}s")
        print(f"  Speedup:        {comparison['speedup']:.2f}x")

        if test_id >= 4 and comparison['speedup'] <= 1.3:
            performance_passed = False
        
        if not comparison['text_match']:
            print(f"\n  Output mismatch:")
            print(f"  Expected: {ref_test['output_text'][:100]}...")
            print(f"  Got:      {student_result['output_text'][:100]}...")
    
    except Exception as e:
        print(f"\n✗ ERROR: {str(e)}")
        results_summary['failed'] += 1
        results_summary['test_results'].append({
            'test_id': test_id,
            'prompt': prompt,
            'passed': False,
            'error': str(e)
        })

print("\n" + "="*80)
print("EVALUATION SUMMARY")
print("="*80)
print(f"\nTotal Tests: {results_summary['total_tests']}")
print(f"Passed:      {results_summary['passed']} ✓")
print(f"Failed:      {results_summary['failed']} ✗")
print(f"Performance Test Passed: {performance_passed}")

total_marks = 0
if results_summary['failed'] == 0 and performance_passed:
    total_marks = 4

print(f"Total Marks:    {total_marks}")

exit(0 if results_summary['failed'] == 0 else 1)