"""
Reference script to generate KV caching outputs
This creates the ground truth JSON file with outputs and timings
"""
from contextlib import nullcontext
import torch
import tiktoken
from model_baseline import GPT
import time
import json

# Enhanced test cases with more variety
test_cases = [
    {"prompt": "Once upon a time", "max_tokens": 20},
    {"prompt": "In the beginning", "max_tokens": 30},
    {"prompt": "The quick brown fox", "max_tokens": 50},
    {"prompt": "To be or not to be, that is the question", "max_tokens": 75},
    {"prompt": "In a galaxy far, far away", "max_tokens": 100},
    {"prompt": "It was the best of times", "max_tokens": 150},
]

init_from = 'gpt2' 
seed = 1337
device = 'cpu' 
dtype = 'float32'
compile = False

# -----------------------------------------------------------------------------

def generate_with_kv_cache(model, prompt, max_new_tokens, encode, decode, device, ctx):
    """
    Generate text using KV caching and measure time.
    Returns the output text and time taken.
    """
    start_ids = encode(prompt)
    x = torch.tensor(start_ids, dtype=torch.long, device=device)[None, ...]
    
    torch.manual_seed(seed) 
    
    with torch.no_grad():
        with ctx:
            start_time = time.perf_counter()
            output = model.generate(x, max_new_tokens, enable_kv_caching=True)
            end_time = time.perf_counter()
    
    time_taken = end_time - start_time
    output_text = decode(output[0].tolist())
    
    return {
        'output_text': output_text,
        'time_taken': time_taken,
        'tokens_generated': len(output[0].tolist())
    }

# -----------------------------------------------------------------------------
# Setup
torch.manual_seed(seed)
if 'cuda' in device:
    torch.cuda.manual_seed(seed)
    torch.backends.cuda.matmul.allow_tf32 = True
    torch.backends.cudnn.allow_tf32 = True

device_type = 'cuda' if 'cuda' in device else 'cpu'
ptdtype = {'float32': torch.float32, 'bfloat16': torch.bfloat16, 'float16': torch.float16}[dtype]
ctx = nullcontext() if device_type == 'cpu' else torch.amp.autocast(device_type=device_type, dtype=ptdtype)

# Load model
print(f"Loading model: {init_from}")
model = GPT.from_pretrained(init_from, dict(dropout=0.0))
model.eval()
model.to(device)

if compile:
    print("Compiling model...")
    model = torch.compile(model)

# Setup encoder/decoder
print("Setting up GPT-2 encodings...")
enc = tiktoken.get_encoding("gpt2")
encode = lambda s: enc.encode(s, allowed_special={"<|endoftext|>"})
decode = lambda l: enc.decode(l)

# -----------------------------------------------------------------------------
# Generate reference outputs
print("\n" + "="*80)
print("GENERATING BASELINE OUTPUTS WITHOUT KV CACHING")
print("="*80)

reference_data = {
    'config': {
        'model': init_from,
        'seed': seed,
        'device': device,
        'dtype': dtype,
        'enable_kv_caching': True
    },
    'test_cases': []
}

for idx, test_case in enumerate(test_cases, 1):
    prompt = test_case["prompt"]
    max_tokens = test_case["max_tokens"]
    
    print(f"\n{'='*80}")
    print(f"Test Case {idx}")
    print(f"Prompt: '{prompt}'")
    print(f"Max new tokens: {max_tokens}")
    print(f"{'='*80}")
    
    result = generate_with_kv_cache(
        model, prompt, max_tokens, encode, decode, device, ctx
    )
    
    test_result = {
        'test_id': idx,
        'prompt': prompt,
        'max_tokens': max_tokens,
        'output_text': result['output_text'],
        'time_taken': result['time_taken'],
        'tokens_generated': result['tokens_generated']
    }
    
    reference_data['test_cases'].append(test_result)
    
    # Print results
    print(f"\nGenerated {result['tokens_generated']} tokens in {result['time_taken']:.4f}s")
    print(f"Output preview: {result['output_text'][:100]}...")

# Save to JSON
output_file = 'reference_outputs.json'
with open(output_file, 'w') as f:
    json.dump(reference_data, f, indent=2)

print("\n" + "="*80)
print(f"✓ Reference outputs saved to: {output_file}")
print("="*80)