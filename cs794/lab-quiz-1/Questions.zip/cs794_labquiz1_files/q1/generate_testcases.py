import argparse
import json
import time
import torch
from solution import SlidingWindowCausalSelfAttention, set_seed


def generate_client_test_cases():
    """
    Generate client-side test cases with various parameter configurations
    """
    test_cases = []
    
    # Define client test configurations
    configs = [
        # (B, T, n_embd, n_head, window_size, seed)
        (1, 4, 32, 2, 2, 42),      # Small test
        (2, 8, 64, 4, 3, 42),      # Medium test
        (1, 10, 128, 8, 5, 42),    # Larger embedding
        (2, 16, 64, 4, 4, 42),     # Longer sequence
        (1, 8, 64, 4, 8, 42),      # Window = sequence length
        (2, 8, 64, 4, 3, 99),      # Different seed
        (1, 12, 96, 6, 4, 42),     # Another config
        (3, 6, 48, 4, 3, 42),      # Different batch size
        (3, 6, 48, 4, 10, 42),     # Window > sequence length
    ]
    
    for idx, (B, T, n_embd, n_head, window_size, seed) in enumerate(configs):
        print(f"Generating client test case {idx + 1}/{len(configs)}...")
        
        set_seed(seed)
        model = SlidingWindowCausalSelfAttention(
            n_embd=n_embd, n_head=n_head, window_size=window_size, seed=seed
        )
        model.eval()
        
        set_seed(seed)
        x = torch.randn(B, T, n_embd)
        
        with torch.no_grad():
            output = model(x)
        
        test_case = {
            "test_id": idx + 1,
            "parameters": {
                "batch_size": B,
                "sequence_length": T,
                "embedding_dim": n_embd,
                "num_heads": n_head,
                "window_size": window_size,
                "seed": seed,
            },
            "expected_output": {
                "shape": list(output.shape),
                "mean": float(output.mean().item()),
                "std": float(output.std().item()),
                "sum": float(output.sum().item()),
                "min": float(output.min().item()),
                "max": float(output.max().item()),
                "first_10_values": output.flatten()[:10].tolist(),
                "last_10_values": output.flatten()[-10:].tolist(),
                "sample_position_0_0": output[0, 0, :5].tolist()
                if B > 0 and T > 0
                else [],
            },
        }
        
        test_cases.append(test_case)
    
    return test_cases


def generate_server_test_cases():
    """
    Generate comprehensive server-side test cases with various parameter configurations
    including edge cases and challenging scenarios
    """
    test_cases = []
    
    # Define server test configurations
    configs = [
        (1, 4, 32, 2, 2, 42),      # Small baseline
        (2, 8, 64, 4, 3, 42),      # Medium baseline
        
        (1, 10, 64, 4, 1, 42),     # Window = 1 (no context)
        (2, 8, 64, 4, 8, 42),      # Window = sequence length
        (1, 5, 48, 3, 20, 42),     # Window >> sequence length
        (2, 15, 96, 6, 7, 42),     # Window < T but significant
        
        (1, 1, 64, 4, 3, 42),      # Single token
        (1, 2, 64, 4, 2, 42),      # Two tokens
        (2, 32, 128, 8, 8, 42),    # Long sequence
        (1, 50, 64, 4, 10, 42),    # Very long sequence
        
        (1, 8, 64, 4, 3, 42),      # Batch = 1
        (5, 8, 64, 4, 3, 42),      # Larger batch
        (8, 6, 48, 4, 3, 42),      # Even larger batch
        
        (2, 8, 16, 2, 3, 42),      # Small embedding
        (2, 8, 256, 8, 4, 42),     # Large embedding
        (1, 8, 512, 16, 5, 42),    # Very large embedding
        
        (2, 8, 64, 1, 3, 42),      # Single head
        (2, 8, 128, 16, 4, 42),    # Many heads
        (1, 10, 256, 32, 5, 42),   # Very many heads
        
        (4, 24, 192, 12, 6, 42),   # Large overall
        (3, 20, 256, 16, 8, 42),   # Large with big window
        (5, 16, 128, 8, 4, 42),    # Large batch
        
        (2, 8, 64, 4, 3, 1),       # Seed = 1
        (2, 8, 64, 4, 3, 99),      # Seed = 99
        (2, 8, 64, 4, 3, 12345),   # Seed = 12345
        (2, 8, 64, 4, 3, 0),       # Seed = 0
        
        (3, 7, 60, 5, 4, 42),      # Non-standard dims
        (2, 9, 72, 6, 5, 42),      # Non-power-of-2
        (4, 11, 88, 8, 6, 42),     # Odd sequence length
        
        (2, 16, 64, 4, 2, 42),     # Long seq, small window
        (1, 25, 128, 8, 3, 42),    # Very long, tiny window
        (3, 12, 96, 6, 12, 42),    # Window = seq (full attention)
        
        (2, 8, 64, 4, 3, 42),      # Duplicate of earlier test
        
        (1, 3, 32, 2, 3, 42),      # Window = seq exactly
        (2, 10, 80, 5, 9, 42),     # Window = seq - 1
        (1, 8, 64, 8, 1, 42),      # Max heads, min window
        
        (6, 14, 168, 12, 7, 42),   # Everything moderately large
        (4, 18, 144, 9, 9, 42),    # Large diverse config
        (7, 10, 120, 10, 5, 42),   # High batch, many heads
        (2, 20, 240, 16, 10, 42),  # Very large with big window
    ]
    
    for idx, (B, T, n_embd, n_head, window_size, seed) in enumerate(configs):
        print(f"Generating server test case {idx + 1}/{len(configs)}...")
        
        set_seed(seed)
        model = SlidingWindowCausalSelfAttention(
            n_embd=n_embd, n_head=n_head, window_size=window_size, seed=seed
        )
        model.eval()
        
        set_seed(seed)
        x = torch.randn(B, T, n_embd)
        
        with torch.no_grad():
            output = model(x)
        
        test_case = {
            "test_id": idx + 1,
            "parameters": {
                "batch_size": B,
                "sequence_length": T,
                "embedding_dim": n_embd,
                "num_heads": n_head,
                "window_size": window_size,
                "seed": seed,
            },
            "expected_output": {
                "shape": list(output.shape),
                "mean": float(output.mean().item()),
                "std": float(output.std().item()),
                "sum": float(output.sum().item()),
                "min": float(output.min().item()),
                "max": float(output.max().item()),
                
                "first_10_values": output.flatten()[:10].tolist(),
                "last_10_values": output.flatten()[-10:].tolist(),
                "middle_10_values": output.flatten()[len(output.flatten())//2:len(output.flatten())//2+10].tolist() if output.numel() >= 20 else [],
                
                "sample_position_0_0": output[0, 0, :5].tolist() if B > 0 and T > 0 else [],
                "sample_position_0_last": output[0, -1, :5].tolist() if B > 0 and T > 0 else [],
                "sample_position_last_0": output[-1, 0, :5].tolist() if B > 1 and T > 0 else [],
                
                "mean_per_batch": [float(output[b].mean().item()) for b in range(min(B, 3))],
                "mean_per_position": [float(output[:, t].mean().item()) for t in range(min(T, 5))],
                
                "has_nan": bool(torch.isnan(output).any().item()),
                "has_inf": bool(torch.isinf(output).any().item()),
                
                "checksum": float(torch.sum(output * torch.arange(1, output.numel() + 1).float().reshape(output.shape)).item()),
            },
        }
        
        test_cases.append(test_case)
    
    return test_cases


def benchmark_reference_time(num_iterations=50, num_warmup=5):
    """
    Benchmark the reference (solution) model on the standard performance
    test configuration and return the total elapsed time in milliseconds
    for num_iterations runs.
    """
    batch_size = 8
    seq_length = 128
    n_embd = 512
    n_head = 8
    window_size = 32
    seed = 42

    print(f"\nBenchmarking reference model ({num_warmup} warmup + {num_iterations} timed iterations)...")

    set_seed(seed)
    model = SlidingWindowCausalSelfAttention(
        n_embd=n_embd, n_head=n_head, window_size=window_size, seed=seed
    )
    model.eval()

    set_seed(seed)
    x = torch.randn(batch_size, seq_length, n_embd)

    # Warmup
    with torch.no_grad():
        for _ in range(num_warmup):
            _ = model(x)

    # Timed runs
    start_time = time.time()
    with torch.no_grad():
        for _ in range(num_iterations):
            _ = model(x)
    elapsed_ms = (time.time() - start_time) * 1000

    avg_ms = elapsed_ms / num_iterations
    print(f"  Total elapsed : {elapsed_ms:.2f} ms over {num_iterations} iterations")
    print(f"  Average per it: {avg_ms:.2f} ms")

    return elapsed_ms


def save_unified_test_cases(filename="test_cases.json"):
    """
    Generate and save both client and server test cases, plus a reference
    benchmark time, in a single JSON file.
    """
    print("=" * 60)
    print("GENERATING CLIENT TEST CASES")
    print("=" * 60)
    client_test_cases = generate_client_test_cases()
    
    print("\n" + "=" * 60)
    print("GENERATING SERVER TEST CASES")
    print("=" * 60)
    server_test_cases = generate_server_test_cases()

    print("\n" + "=" * 60)
    print("BENCHMARKING REFERENCE MODEL")
    print("=" * 60)
    reference_time_ms = benchmark_reference_time(num_iterations=50, num_warmup=5)

    output = {
        "description": "Unified test cases for Sliding Window Causal Self-Attention",
        "client_tests": {
            "description": "Client-side test cases with basic parameter configurations",
            "total_tests": len(client_test_cases),
            "test_cases": client_test_cases,
        },
        "server_tests": {
            "description": "Server-side test cases with comprehensive coverage including edge cases",
            "total_tests": len(server_test_cases),
            "test_cases": server_test_cases,
        },
        "performance_benchmark": {
            "description": (
                "Reference timing from the solution model on the standard performance "
                "configuration (B=8, T=128, n_embd=512, n_head=8, window_size=32). "
                "Measured as total elapsed ms over 50 iterations after 5 warmup runs."
            ),
            "config": {
                "batch_size": 8,
                "sequence_length": 128,
                "n_embd": 512,
                "n_head": 8,
                "window_size": 32,
                "seed": 42,
                "num_iterations": 50,
                "num_warmup": 5,
            },
            "reference_time_ms": reference_time_ms,
            "tolerance_factor": 2.0,
        },
        "summary": {
            "total_client_tests": len(client_test_cases),
            "total_server_tests": len(server_test_cases),
            "total_all_tests": len(client_test_cases) + len(server_test_cases),
        }
    }
    
    with open(filename, "w") as f:
        json.dump(output, f, indent=2)
    
    print("\n" + "=" * 60)
    print("SUMMARY")
    print("=" * 60)
    print(f"Client test cases   : {len(client_test_cases)}")
    print(f"Server test cases   : {len(server_test_cases)}")
    print(f"Total test cases    : {len(client_test_cases) + len(server_test_cases)}")
    print(f"Reference time (ms) : {reference_time_ms:.2f}  (tolerance ×2.0)")
    print(f"\nSaved to: {filename}")
    print(f"File size: {len(json.dumps(output))} bytes")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Generate unified test cases for Sliding Window Causal Self-Attention"
    )
    parser.add_argument(
        "--output_file",
        type=str,
        default="test_cases.json",
        help="Output JSON file for unified test cases"
    )
    args = parser.parse_args()
    
    save_unified_test_cases(args.output_file)