import torch
import torch.nn.functional as F
import json
import time
from student import SlidingWindowCausalSelfAttention, set_seed
import math


def load_and_grade_client(student_model_class, json_file="test_cases.json", tolerance=1e-5):
    with open(json_file, 'r') as f:
        data = json.load(f)
    
    test_cases = data["client_tests"]["test_cases"]
    passed = 0
    failed = 0
    
    print(f"Running {len(test_cases)} client test cases...\n")
    
    for test in test_cases:
        test_id = test["test_id"]
        params = test["parameters"]
        expected = test["expected_output"]
        
        try:
            set_seed(params["seed"])
            
            model = student_model_class(
                n_embd=params["embedding_dim"],
                n_head=params["num_heads"],
                window_size=params["window_size"],
                seed=params["seed"]
            )
            model.eval()
            
            set_seed(params["seed"])
            x = torch.randn(
                params["batch_size"],
                params["sequence_length"],
                params["embedding_dim"]
            )
            
            with torch.no_grad():
                output = model(x)
            
            if list(output.shape) != expected["shape"]:
                failed += 1
                continue
            
            mean_diff = abs(output.mean().item() - expected["mean"])
            std_diff = abs(output.std().item() - expected["std"])
            sum_diff = abs(output.sum().item() - expected["sum"])
            
            first_vals = output.flatten()[:10].tolist()
            first_vals_match = all(
                abs(a - b) < tolerance 
                for a, b in zip(first_vals, expected["first_10_values"])
            )
            
            if (mean_diff < tolerance and 
                std_diff < tolerance and 
                sum_diff < tolerance * 10 and 
                first_vals_match):
                passed += 1
            else:
                failed += 1
                
        except Exception as e:
            failed += 1
    
    return passed, failed


def load_and_grade_server(student_model_class, json_file="test_cases.json", tolerance=1e-5):
    with open(json_file, 'r') as f:
        data = json.load(f)
    
    test_cases = data["server_tests"]["test_cases"]
    passed = 0
    failed = 0
    
    print(f"Running {len(test_cases)} server test cases...\n")
    
    for test in test_cases:
        test_id = test["test_id"]
        params = test["parameters"]
        expected = test["expected_output"]
        
        try:
            set_seed(params["seed"])
            
            model = student_model_class(
                n_embd=params["embedding_dim"],
                n_head=params["num_heads"],
                window_size=params["window_size"],
                seed=params["seed"]
            )
            model.eval()
            
            set_seed(params["seed"])
            x = torch.randn(
                params["batch_size"],
                params["sequence_length"],
                params["embedding_dim"]
            )
            
            with torch.no_grad():
                output = model(x)
            
            if list(output.shape) != expected["shape"]:
                failed += 1
                continue
            
            if torch.isnan(output).any() or torch.isinf(output).any():
                failed += 1
                continue
            
            mean_diff = abs(output.mean().item() - expected["mean"])
            std_diff = abs(output.std().item() - expected["std"])
            sum_diff = abs(output.sum().item() - expected["sum"])
            
            first_vals = output.flatten()[:10].tolist()
            first_vals_match = all(
                abs(a - b) < tolerance 
                for a, b in zip(first_vals, expected["first_10_values"])
            )
            
            last_vals = output.flatten()[-10:].tolist()
            last_vals_match = all(
                abs(a - b) < tolerance 
                for a, b in zip(last_vals, expected["last_10_values"])
            )
            
            checksum = float(torch.sum(output * torch.arange(1, output.numel() + 1).float().reshape(output.shape)).item())
            checksum_diff = abs(checksum - expected["checksum"])
            
            if (mean_diff < tolerance and 
                std_diff < tolerance and 
                sum_diff < tolerance * 10 and 
                first_vals_match and
                last_vals_match and
                checksum_diff < tolerance * 100):
                passed += 1
            else:
                failed += 1
                
        except Exception as e:
            failed += 1
    
    return passed, failed


def benchmark_performance(student_model_class, json_file="test_cases.json"):
    """
    Run the student model on the standard performance configuration and compare
    its total elapsed time against the reference time stored in the JSON.

    The student must complete 50 iterations within
        reference_time_ms * tolerance_factor
    milliseconds (both values are read from the JSON).
    """
    with open(json_file, 'r') as f:
        data = json.load(f)

    bench_cfg = data["performance_benchmark"]
    cfg = bench_cfg["config"]
    reference_time_ms = bench_cfg["reference_time_ms"]
    tolerance_factor = bench_cfg["tolerance_factor"]

    batch_size   = cfg["batch_size"]
    seq_length   = cfg["sequence_length"]
    n_embd       = cfg["n_embd"]
    n_head       = cfg["n_head"]
    window_size  = cfg["window_size"]
    seed         = cfg["seed"]
    num_iterations = cfg["num_iterations"]
    num_warmup   = cfg["num_warmup"]

    max_allowed_time_ms = reference_time_ms * tolerance_factor

    print(f"  Reference time : {reference_time_ms:.2f} ms  (tolerance ×{tolerance_factor})")
    print(f"  Max allowed    : {max_allowed_time_ms:.2f} ms  over {num_iterations} iterations")

    try:
        set_seed(seed)
        model = student_model_class(
            n_embd=n_embd,
            n_head=n_head,
            window_size=window_size,
            seed=seed
        )
        model.eval()

        set_seed(seed)
        x = torch.randn(batch_size, seq_length, n_embd)

        # Warmup
        with torch.no_grad():
            for _ in range(num_warmup):
                _ = model(x)

        # Timed runs
        start_time = time.time()
        with torch.no_grad():
            for _ in range(num_iterations):
                _ = model(x)
        elapsed_ms = (time.time() - start_time) * 1000

        avg_ms = elapsed_ms / num_iterations
        print(f"  Student total  : {elapsed_ms:.2f} ms  (avg {avg_ms:.2f} ms/it)")

        if elapsed_ms <= max_allowed_time_ms:
            speedup = reference_time_ms / elapsed_ms
            print(f"  Result         : PASSED  (speedup {speedup:.2f}×)")
            return True
        else:
            slowdown = elapsed_ms / reference_time_ms
            print(f"  Result         : FAILED  (slowdown {slowdown:.2f}×)")
            return False

    except Exception as e:
        print(f"  Result         : FAILED  (exception: {e})")
        return False


if __name__ == "__main__":
    
    total_marks = 0
    
    print("=" * 70)
    print("CLIENT SIDE TEST CASES")
    print("=" * 70)
    
    # Client Side Testcases
    client_passed, client_failed = load_and_grade_client(
        SlidingWindowCausalSelfAttention,
        "test_cases.json"
    )
    
    print(f"Out of 9 client side testcases, {client_passed} passed!")
    total_marks += client_passed * 2 / 9
    
    print("\n" + "=" * 70)
    print("SERVER SIDE TEST CASES")
    print("=" * 70)
    
    # Server Side Testcases
    server_passed, server_failed = load_and_grade_server(
        SlidingWindowCausalSelfAttention, 
        "test_cases.json"
    )
    
    print(f"Out of 40 server side testcases, {server_passed} passed!")
    total_marks += server_passed * 1.5 / 40
    
    print("\n" + "=" * 70)
    print("PERFORMANCE TEST")
    print("=" * 70)
    
    if server_failed == 0:
        perf_passed = benchmark_performance(
            SlidingWindowCausalSelfAttention,
            json_file="test_cases.json",
        )
        if perf_passed:
            total_marks += 0.5
        
        print(f"Performance Test Success: {perf_passed}!")
    else:
        print(f"Performance Test Success: {False}!")
        print("(Performance test skipped due to failed correctness tests)")
    
    print("\n" + "=" * 70)
    print("FINAL RESULTS")
    print("=" * 70)
    print(f"Client tests passed: {client_passed}/9")
    print(f"Server tests passed: {server_passed}/40")
    rounded_marks = math.ceil(total_marks * 100) / 100
    print(f"Total marks for q1: {rounded_marks:.2f}/4.00")