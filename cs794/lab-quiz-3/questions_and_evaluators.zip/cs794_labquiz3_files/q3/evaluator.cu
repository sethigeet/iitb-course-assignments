// ============================================================
// evaluator.cu
// DO NOT MODIFY THIS FILE.
// Student code will be injected between the marked boundaries.
// ============================================================


#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <cuda_runtime.h>
#include <time.h>

// ======================
// START OF STUDENT CODE
// ======================

// <<< STUDENT CODE WILL BE INJECTED HERE BY THE GRADING SCRIPT >>>

// ====================
// END OF STUDENT CODE
// ====================

// ======================================================================
// TESTING INFRASTRUCTURE: PLEASE DON'T CHANGE ANYTHING BELOW THIS LINE.
// ======================================================================

// ============================================================
// CPU REFERENCE IMPLEMENTATION
// ============================================================

static void cpu_relu(float* x, int n) {
    for (int i = 0; i < n; i++)
        x[i] = x[i] > 0.0f ? x[i] : 0.0f;
}

static void cpu_matmul(const float* A, const float* B, float* C,
                       int M, int K, int N)
{
    for (int i = 0; i < M; i++)
        for (int j = 0; j < N; j++) {
            float s = 0.0f;
            for (int k = 0; k < K; k++)
                s += A[i * K + k] * B[k * N + j];
            C[i * N + j] = s;
        }
}

static void cpu_add_bias(float* C, const float* bias, int M, int N) {
    for (int i = 0; i < M; i++)
        for (int j = 0; j < N; j++)
            C[i * N + j] += bias[j];
}

static void cpu_transpose(const float* A, float* AT, int R, int C) {
    for (int i = 0; i < R; i++)
        for (int j = 0; j < C; j++)
            AT[j * R + i] = A[i * C + j];
}

static void cpu_forward(
    const float* X,
    const float* W1, const float* b1,
    const float* W2, const float* b2,
    const float* W3, const float* b3,
    float* Z1, float* A1,
    float* Z2, float* A2,
    float* Z3,
    int N, int IN, int H1, int H2, int OUT)
{
    // Layer 1
    cpu_matmul(X,  W1, Z1, N, IN, H1);
    cpu_add_bias(Z1, b1, N, H1);
    memcpy(A1, Z1, N * H1 * sizeof(float));
    cpu_relu(A1, N * H1);

    // Layer 2
    cpu_matmul(A1, W2, Z2, N, H1, H2);
    cpu_add_bias(Z2, b2, N, H2);
    memcpy(A2, Z2, N * H2 * sizeof(float));
    cpu_relu(A2, N * H2);

    // Layer 3
    cpu_matmul(A2, W3, Z3, N, H2, OUT);
    cpu_add_bias(Z3, b3, N, OUT);
}

static void cpu_backward(
    const float* X, const float* target,
    float* W1, float* b1,
    float* W2, float* b2,
    float* W3, float* b3,
    const float* Z1, const float* A1,
    const float* Z2, const float* A2,
    const float* Z3,
    float* dW1, float* db1,
    float* dW2, float* db2,
    float* dW3, float* db3,
    float lr,
    int N, int IN, int H1, int H2, int OUT)
{
    // dL/dZ3 = MSE gradient  [N x OUT]
    float* dZ3 = (float*)malloc(N * OUT * sizeof(float));
    int tot3 = N * OUT;
    for (int i = 0; i < tot3; i++)
        dZ3[i] = (Z3[i] - target[i]) * 2.0f / tot3;

    // Layer 3 weight gradients
    float* A2T = (float*)malloc(H2 * N * sizeof(float));
    cpu_transpose(A2, A2T, N, H2);
    cpu_matmul(A2T, dZ3, dW3, H2, N, OUT);
    free(A2T);

    for (int j = 0; j < OUT; j++) {
        float s = 0.0f;
        for (int i = 0; i < N; i++) s += dZ3[i * OUT + j];
        db3[j] = s;
    }

    // Layer 2 backward
    float* dZ2 = (float*)malloc(N * H2 * sizeof(float));
    float* W3T = (float*)malloc(OUT * H2 * sizeof(float));
    cpu_transpose(W3, W3T, H2, OUT);
    cpu_matmul(dZ3, W3T, dZ2, N, OUT, H2);
    free(W3T);

    for (int i = 0; i < N * H2; i++)
        dZ2[i] *= (Z2[i] > 0.0f) ? 1.0f : 0.0f;

    float* A1T = (float*)malloc(H1 * N * sizeof(float));
    cpu_transpose(A1, A1T, N, H1);
    cpu_matmul(A1T, dZ2, dW2, H1, N, H2);
    free(A1T);

    for (int j = 0; j < H2; j++) {
        float s = 0.0f;
        for (int i = 0; i < N; i++) s += dZ2[i * H2 + j];
        db2[j] = s;
    }

    // Layer 1 backward
    float* dZ1 = (float*)malloc(N * H1 * sizeof(float));
    float* W2T = (float*)malloc(H2 * H1 * sizeof(float));
    cpu_transpose(W2, W2T, H1, H2);
    cpu_matmul(dZ2, W2T, dZ1, N, H2, H1);
    free(W2T);

    for (int i = 0; i < N * H1; i++)
        dZ1[i] *= (Z1[i] > 0.0f) ? 1.0f : 0.0f;

    float* XT = (float*)malloc(IN * N * sizeof(float));
    cpu_transpose(X, XT, N, IN);
    cpu_matmul(XT, dZ1, dW1, IN, N, H1);
    free(XT);

    for (int j = 0; j < H1; j++) {
        float s = 0.0f;
        for (int i = 0; i < N; i++) s += dZ1[i * H1 + j];
        db1[j] = s;
    }

    // SGD updates
    for (int i = 0; i < IN * H1; i++) W1[i] -= lr * dW1[i];
    for (int i = 0; i < H1;      i++) b1[i] -= lr * db1[i];
    for (int i = 0; i < H1 * H2; i++) W2[i] -= lr * dW2[i];
    for (int i = 0; i < H2;      i++) b2[i] -= lr * db2[i];
    for (int i = 0; i < H2 * OUT;i++) W3[i] -= lr * dW3[i];
    for (int i = 0; i < OUT;     i++) b3[i] -= lr * db3[i];

    free(dZ3); free(dZ2); free(dZ1);
}

// ============================================================
// TESTING INFRASTRUCTURE
// ============================================================

static void fill_random(float* data, int n, unsigned int* seed) {
    for (int i = 0; i < n; i++)
        data[i] = ((float)(rand_r(seed) % 2001) - 1000.0f) / 1000.0f;
}

static int compare_arrays(const char* name,
                           const float* ref, const float* got,
                           int n, float tol)
{
    int ok = 1;
    for (int i = 0; i < n; i++) {
        float diff = fabsf(ref[i] - got[i]);
        if (diff > tol) {
            printf("  [%s] MISMATCH at idx %d: cpu=%.6f  gpu=%.6f  diff=%.2e\n",
                   name, i, ref[i], got[i], diff);
            ok = 0;
            break;
        }
    }
    return ok;
}

static void gpu_forward_backward(
    const float* h_X, const float* h_target,
    float* h_W1, float* h_b1,
    float* h_W2, float* h_b2,
    float* h_W3, float* h_b3,
    float* h_dW1, float* h_db1,
    float* h_dW2, float* h_db2,
    float* h_dW3, float* h_db3,
    float* h_Z3_out,
    float lr,
    int N, int IN, int H1, int H2, int OUT)
{
    float *X, *target;
    float *W1, *b1, *W2, *b2, *W3, *b3;
    float *A2, *Z3;
    float *dW1, *db1, *dW2, *db2, *dW3, *db3;

    cudaMalloc(&X,      N * IN  * sizeof(float));
    cudaMalloc(&target, N * OUT * sizeof(float));
    cudaMalloc(&W1, IN * H1 * sizeof(float));  cudaMalloc(&b1, H1  * sizeof(float));
    cudaMalloc(&W2, H1 * H2 * sizeof(float));  cudaMalloc(&b2, H2  * sizeof(float));
    cudaMalloc(&W3, H2 * OUT* sizeof(float));  cudaMalloc(&b3, OUT * sizeof(float));
    cudaMalloc(&A2, N  * H2  * sizeof(float));
    cudaMalloc(&Z3, N  * OUT * sizeof(float));
    cudaMalloc(&dW1, IN * H1 * sizeof(float)); cudaMemset(dW1, 0, IN * H1 * sizeof(float));
    cudaMalloc(&db1, H1  * sizeof(float));     cudaMemset(db1, 0, H1  * sizeof(float));
    cudaMalloc(&dW2, H1 * H2 * sizeof(float)); cudaMemset(dW2, 0, H1 * H2 * sizeof(float));
    cudaMalloc(&db2, H2  * sizeof(float));     cudaMemset(db2, 0, H2  * sizeof(float));
    cudaMalloc(&dW3, H2 * OUT* sizeof(float)); cudaMemset(dW3, 0, H2 * OUT* sizeof(float));
    cudaMalloc(&db3, OUT * sizeof(float));     cudaMemset(db3, 0, OUT * sizeof(float));

    cudaMemcpy(X,      h_X,      N * IN  * sizeof(float), cudaMemcpyHostToDevice);
    cudaMemcpy(target, h_target, N * OUT * sizeof(float), cudaMemcpyHostToDevice);
    cudaMemcpy(W1, h_W1, IN * H1 * sizeof(float), cudaMemcpyHostToDevice);
    cudaMemcpy(b1, h_b1, H1      * sizeof(float), cudaMemcpyHostToDevice);
    cudaMemcpy(W2, h_W2, H1 * H2 * sizeof(float), cudaMemcpyHostToDevice);
    cudaMemcpy(b2, h_b2, H2      * sizeof(float), cudaMemcpyHostToDevice);
    cudaMemcpy(W3, h_W3, H2 * OUT* sizeof(float), cudaMemcpyHostToDevice);
    cudaMemcpy(b3, h_b3, OUT     * sizeof(float), cudaMemcpyHostToDevice);

    forward_pass(X, W1, b1, W2, b2, W3, b3, A2, Z3, N, IN, H1, H2, OUT);
    cudaDeviceSynchronize();

    backward_pass(X, target,
                  W1, W2, W3, b1, b2, b3,
                  A2, Z3,
                  dW1, dW2, dW3, db1, db2, db3,
                  lr, N, IN, H1, H2, OUT);
    cudaDeviceSynchronize();

    cudaMemcpy(h_W1, W1, IN * H1 * sizeof(float), cudaMemcpyDeviceToHost);
    cudaMemcpy(h_b1, b1, H1      * sizeof(float), cudaMemcpyDeviceToHost);
    cudaMemcpy(h_W2, W2, H1 * H2 * sizeof(float), cudaMemcpyDeviceToHost);
    cudaMemcpy(h_b2, b2, H2      * sizeof(float), cudaMemcpyDeviceToHost);
    cudaMemcpy(h_W3, W3, H2 * OUT* sizeof(float), cudaMemcpyDeviceToHost);
    cudaMemcpy(h_b3, b3, OUT     * sizeof(float), cudaMemcpyDeviceToHost);
    cudaMemcpy(h_dW1, dW1, IN * H1 * sizeof(float), cudaMemcpyDeviceToHost);
    cudaMemcpy(h_db1, db1, H1      * sizeof(float), cudaMemcpyDeviceToHost);
    cudaMemcpy(h_dW2, dW2, H1 * H2 * sizeof(float), cudaMemcpyDeviceToHost);
    cudaMemcpy(h_db2, db2, H2      * sizeof(float), cudaMemcpyDeviceToHost);
    cudaMemcpy(h_dW3, dW3, H2 * OUT* sizeof(float), cudaMemcpyDeviceToHost);
    cudaMemcpy(h_db3, db3, OUT     * sizeof(float), cudaMemcpyDeviceToHost);
    cudaMemcpy(h_Z3_out, Z3, N * OUT * sizeof(float), cudaMemcpyDeviceToHost);

    cudaFree(X);  cudaFree(target);
    cudaFree(W1); cudaFree(b1); cudaFree(W2); cudaFree(b2);
    cudaFree(W3); cudaFree(b3);
    cudaFree(A2); cudaFree(Z3);
    cudaFree(dW1); cudaFree(db1); cudaFree(dW2); cudaFree(db2);
    cudaFree(dW3); cudaFree(db3);
}

static bool run_test(const char* label,
                     int N, int IN, int H1, int H2, int OUT,
                     float lr, float tol)
{
    printf("=== %s: N=%d IN=%d H1=%d H2=%d OUT=%d lr=%.4f ===\n",
           label, N, IN, H1, H2, OUT, lr);

    unsigned int seed = 42;

    float *h_X      = (float*)malloc(N * IN  * sizeof(float));
    float *h_target = (float*)malloc(N * OUT * sizeof(float));

    float *gW1 = (float*)malloc(IN * H1 * sizeof(float));
    float *gb1 = (float*)malloc(H1       * sizeof(float));
    float *gW2 = (float*)malloc(H1 * H2 * sizeof(float));
    float *gb2 = (float*)malloc(H2       * sizeof(float));
    float *gW3 = (float*)malloc(H2 * OUT * sizeof(float));
    float *gb3 = (float*)malloc(OUT      * sizeof(float));

    float *cW1 = (float*)malloc(IN * H1 * sizeof(float));
    float *cb1 = (float*)malloc(H1       * sizeof(float));
    float *cW2 = (float*)malloc(H1 * H2 * sizeof(float));
    float *cb2 = (float*)malloc(H2       * sizeof(float));
    float *cW3 = (float*)malloc(H2 * OUT * sizeof(float));
    float *cb3 = (float*)malloc(OUT      * sizeof(float));

    fill_random(h_X,      N * IN,  &seed);
    fill_random(h_target, N * OUT, &seed);
    fill_random(gW1, IN * H1, &seed);  fill_random(gb1, H1,  &seed);
    fill_random(gW2, H1 * H2, &seed);  fill_random(gb2, H2,  &seed);
    fill_random(gW3, H2 * OUT,&seed);  fill_random(gb3, OUT, &seed);

    memcpy(cW1, gW1, IN * H1 * sizeof(float));
    memcpy(cb1, gb1, H1       * sizeof(float));
    memcpy(cW2, gW2, H1 * H2 * sizeof(float));
    memcpy(cb2, gb2, H2       * sizeof(float));
    memcpy(cW3, gW3, H2 * OUT * sizeof(float));
    memcpy(cb3, gb3, OUT      * sizeof(float));

    float *gdW1 = (float*)calloc(IN * H1, sizeof(float));
    float *gdb1 = (float*)calloc(H1,       sizeof(float));
    float *gdW2 = (float*)calloc(H1 * H2, sizeof(float));
    float *gdb2 = (float*)calloc(H2,       sizeof(float));
    float *gdW3 = (float*)calloc(H2 * OUT, sizeof(float));
    float *gdb3 = (float*)calloc(OUT,      sizeof(float));
    float *gZ3  = (float*)calloc(N * OUT,  sizeof(float));

    float *cdW1 = (float*)calloc(IN * H1, sizeof(float));
    float *cdb1 = (float*)calloc(H1,       sizeof(float));
    float *cdW2 = (float*)calloc(H1 * H2, sizeof(float));
    float *cdb2 = (float*)calloc(H2,       sizeof(float));
    float *cdW3 = (float*)calloc(H2 * OUT, sizeof(float));
    float *cdb3 = (float*)calloc(OUT,      sizeof(float));

    float *cZ1 = (float*)malloc(N * H1  * sizeof(float));
    float *cA1 = (float*)malloc(N * H1  * sizeof(float));
    float *cZ2 = (float*)malloc(N * H2  * sizeof(float));
    float *cA2 = (float*)malloc(N * H2  * sizeof(float));
    float *cZ3 = (float*)malloc(N * OUT * sizeof(float));

    cpu_forward(h_X, cW1, cb1, cW2, cb2, cW3, cb3,
                cZ1, cA1, cZ2, cA2, cZ3,
                N, IN, H1, H2, OUT);

    cpu_backward(h_X, h_target,
                 cW1, cb1, cW2, cb2, cW3, cb3,
                 cZ1, cA1, cZ2, cA2, cZ3,
                 cdW1, cdb1, cdW2, cdb2, cdW3, cdb3,
                 lr, N, IN, H1, H2, OUT);

    gpu_forward_backward(h_X, h_target,
                         gW1, gb1, gW2, gb2, gW3, gb3,
                         gdW1, gdb1, gdW2, gdb2, gdW3, gdb3,
                         gZ3, lr,
                         N, IN, H1, H2, OUT);

    cudaError_t err = cudaGetLastError();
    bool passed = (err == cudaSuccess);
    if (err != cudaSuccess) {
        printf("  CUDA error: %s\n  Result: FAIL\n\n", cudaGetErrorString(err));
        goto cleanup;
    }

    {
        int all_ok = 1;
        all_ok &= compare_arrays("Z3 (forward output)", cZ3,  gZ3,  N * OUT, tol);
        all_ok &= compare_arrays("dW1", cdW1, gdW1, IN * H1, tol);
        all_ok &= compare_arrays("db1", cdb1, gdb1, H1,       tol);
        all_ok &= compare_arrays("dW2", cdW2, gdW2, H1 * H2,  tol);
        all_ok &= compare_arrays("db2", cdb2, gdb2, H2,       tol);
        all_ok &= compare_arrays("dW3", cdW3, gdW3, H2 * OUT, tol);
        all_ok &= compare_arrays("db3", cdb3, gdb3, OUT,      tol);
        all_ok &= compare_arrays("W1 (post-update)", cW1, gW1, IN * H1, tol);
        all_ok &= compare_arrays("b1 (post-update)", cb1, gb1, H1,       tol);
        all_ok &= compare_arrays("W2 (post-update)", cW2, gW2, H1 * H2,  tol);
        all_ok &= compare_arrays("b2 (post-update)", cb2, gb2, H2,       tol);
        all_ok &= compare_arrays("W3 (post-update)", cW3, gW3, H2 * OUT, tol);
        all_ok &= compare_arrays("b3 (post-update)", cb3, gb3, OUT,      tol);
        if (all_ok) {
            passed = true;
        }
        else {
            passed = false;
        }
        printf("  Result: %s\n\n", all_ok ? "PASS" : "FAIL");
    }

cleanup:
    free(h_X); free(h_target);
    free(gW1); free(gb1); free(gW2); free(gb2); free(gW3); free(gb3);
    free(cW1); free(cb1); free(cW2); free(cb2); free(cW3); free(cb3);
    free(gdW1); free(gdb1); free(gdW2); free(gdb2); free(gdW3); free(gdb3); free(gZ3);
    free(cdW1); free(cdb1); free(cdW2); free(cdb2); free(cdW3); free(cdb3);
    free(cZ1); free(cA1); free(cZ2); free(cA2); free(cZ3);

    return passed;
}

// ============================================================
// CPU REFERENCES FOR KERNEL-LEVEL TESTS
// ============================================================

static void cpu_bias_gradient(const float* dZ, float* db, int N, int D)
{
    for (int j = 0; j < D; j++) {
        float s = 0.0f;
        for (int i = 0; i < N; i++)
            s += dZ[i * D + j];
        db[j] = s;
    }
}

static void cpu_relu_derivative(const float* x, float* dx, int size)
{
    for (int i = 0; i < size; i++)
        dx[i] *= (x[i] > 0.0f) ? 1.0f : 0.0f;
}

// ============================================================
// GPU LAUNCHERS FOR KERNEL-LEVEL TESTS
// ============================================================

static void launch_bias_gradient(const float* h_dZ, float* h_db, int N, int D)
{
    float *d_dZ, *d_db;
    cudaMalloc(&d_dZ, N * D * sizeof(float));
    cudaMalloc(&d_db, D     * sizeof(float));

    cudaMemcpy(d_dZ, h_dZ, N * D * sizeof(float), cudaMemcpyHostToDevice);
    cudaMemset(d_db, 0,    D     * sizeof(float));

    int threads = 256;
    int blocks  = (D + threads - 1) / threads;
    bias_gradient<<<blocks, threads>>>(d_dZ, d_db, N, D);
    cudaDeviceSynchronize();

    cudaMemcpy(h_db, d_db, D * sizeof(float), cudaMemcpyDeviceToHost);
    cudaFree(d_dZ);
    cudaFree(d_db);
}

static void launch_relu_derivative(const float* h_x, float* h_dx, int size)
{
    float *d_x, *d_dx;
    cudaMalloc(&d_x,  size * sizeof(float));
    cudaMalloc(&d_dx, size * sizeof(float));

    cudaMemcpy(d_x,  h_x,  size * sizeof(float), cudaMemcpyHostToDevice);
    cudaMemcpy(d_dx, h_dx, size * sizeof(float), cudaMemcpyHostToDevice);

    int threads = 256;
    int blocks  = (size + threads - 1) / threads;
    relu_derivative<<<blocks, threads>>>(d_x, d_dx, size);
    cudaDeviceSynchronize();

    cudaMemcpy(h_dx, d_dx, size * sizeof(float), cudaMemcpyDeviceToHost);
    cudaFree(d_x);
    cudaFree(d_dx);
}

// ============================================================
// KERNEL-LEVEL TEST RUNNERS
// ============================================================

static bool test_bias_gradient(const char* label,
                                int N, int D,
                                float tol, unsigned int seed)
{
    printf("  [bias_gradient] %s  N=%d D=%d\n", label, N, D);

    float* dZ     = (float*)malloc(N * D * sizeof(float));
    float* cpu_db = (float*)calloc(D, sizeof(float));
    float* gpu_db = (float*)calloc(D, sizeof(float));

    fill_random(dZ, N * D, &seed);

    cpu_bias_gradient(dZ, cpu_db, N, D);
    launch_bias_gradient(dZ, gpu_db, N, D);

    cudaError_t err = cudaGetLastError();
    bool passed = (err == cudaSuccess);
    if (err != cudaSuccess) {
        printf("    CUDA error: %s  -> FAIL\n", cudaGetErrorString(err));
    } else {
        int ok = compare_arrays("db", cpu_db, gpu_db, D, tol);
        passed = ok ? true : false;
        printf("    Result: %s\n", ok ? "PASS" : "FAIL");
    }

    free(dZ); free(cpu_db); free(gpu_db);
    return passed;
}

static bool test_relu_derivative(const char* label,
                                  int size,
                                  float tol, unsigned int seed)
{
    bool passed = true;
    printf("  [relu_derivative] %s  size=%d\n", label, size);

    float* x      = (float*)malloc(size * sizeof(float));
    float* cpu_dx = (float*)malloc(size * sizeof(float));
    float* gpu_dx = (float*)malloc(size * sizeof(float));

    fill_random(x,      size, &seed);
    fill_random(cpu_dx, size, &seed);
    memcpy(gpu_dx, cpu_dx, size * sizeof(float));

    cpu_relu_derivative(x, cpu_dx, size);
    launch_relu_derivative(x, gpu_dx, size);

    cudaError_t err = cudaGetLastError();
    passed = (err == cudaSuccess);
    if (err != cudaSuccess) {
        printf("    CUDA error: %s  -> FAIL\n", cudaGetErrorString(err));
    } else {
        int ok = compare_arrays("dx", cpu_dx, gpu_dx, size, tol);
        if (!ok) passed = false;
        printf("    Result: %s\n", ok ? "PASS" : "FAIL");
    }

    free(x); free(cpu_dx); free(gpu_dx);
    return passed;
}

// ============================================================
// MAIN
// ============================================================

int main(void)
{
    srand(41);

    int passed = 0;

    passed += run_test("Test1", /*N=*/4, /*IN=*/8, /*H1=*/8, /*H2=*/8, /*OUT=*/4, /*lr=*/0.01f, /*tol=*/1e-3f);

    passed += run_test("Test2", /*N=*/16, /*IN=*/32, /*H1=*/32, /*H2=*/32, /*OUT=*/16, /*lr=*/0.001f, /*tol=*/1e-3f);

    passed += run_test("Test3", /*N=*/32, /*IN=*/64, /*H1=*/128, /*H2=*/64, /*OUT=*/32, /*lr=*/0.001f, /*tol=*/1e-3f);

    passed += run_test("Test4",  /*N=*/16,  /*IN=*/32,  /*H1=*/64,  /*H2=*/32,  /*OUT=*/8,  /*lr=*/1.0f,   /*tol=*/1e-2f);

    printf("Total Passed: %d\n", passed);
    return 0;
}
