// ============================================================
// evaluator2.cu
// Kernel-level tests ONLY: bias_gradient and relu_derivative.
// DO NOT MODIFY THIS FILE.
// ============================================================

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <cuda_runtime.h>
#include <time.h>

// ======================
// START OF STUDENT CODE
// ======================

// <<< STUDENT CODE WILL BE INJECTED HERE BY THE GRADING SCRIPT >>>

// ====================
// END OF STUDENT CODE
// ====================

// ======================================================================
// TESTING INFRASTRUCTURE: PLEASE DON'T CHANGE ANYTHING BELOW THIS LINE.
// ======================================================================

// ============================================================
// HELPER UTILITIES
// ============================================================

static void fill_random(float* data, int n, unsigned int* seed) {
    for (int i = 0; i < n; i++)
        data[i] = ((float)(rand_r(seed) % 2001) - 1000.0f) / 1000.0f;
}

static int compare_arrays(const char* name,
                           const float* ref, const float* got,
                           int n, float tol)
{
    int ok = 1;
    for (int i = 0; i < n; i++) {
        float diff = fabsf(ref[i] - got[i]);
        if (diff > tol) {
            printf("  [%s] MISMATCH at idx %d: cpu=%.6f  gpu=%.6f  diff=%.2e\n",
                   name, i, ref[i], got[i], diff);
            ok = 0;
            break;
        }
    }
    return ok;
}

// ============================================================
// CPU REFERENCES FOR KERNEL-LEVEL TESTS
// ============================================================

static void cpu_bias_gradient(const float* dZ, float* db, int N, int D)
{
    for (int j = 0; j < D; j++) {
        float s = 0.0f;
        for (int i = 0; i < N; i++)
            s += dZ[i * D + j];
        db[j] = s;
    }
}

static void cpu_relu_derivative(const float* x, float* dx, int size)
{
    for (int i = 0; i < size; i++)
        dx[i] *= (x[i] > 0.0f) ? 1.0f : 0.0f;
}

// ============================================================
// GPU LAUNCHERS FOR KERNEL-LEVEL TESTS
// ============================================================

static void launch_bias_gradient(const float* h_dZ, float* h_db, int N, int D)
{
    float *d_dZ, *d_db;
    cudaMalloc(&d_dZ, N * D * sizeof(float));
    cudaMalloc(&d_db, D     * sizeof(float));

    cudaMemcpy(d_dZ, h_dZ, N * D * sizeof(float), cudaMemcpyHostToDevice);
    cudaMemset(d_db, 0,    D     * sizeof(float));

    int threads = 256;
    int blocks  = (D + threads - 1) / threads;
    bias_gradient<<<blocks, threads>>>(d_dZ, d_db, N, D);
    cudaDeviceSynchronize();

    cudaMemcpy(h_db, d_db, D * sizeof(float), cudaMemcpyDeviceToHost);
    cudaFree(d_dZ);
    cudaFree(d_db);
}

static void launch_relu_derivative(const float* h_x, float* h_dx, int size)
{
    float *d_x, *d_dx;
    cudaMalloc(&d_x,  size * sizeof(float));
    cudaMalloc(&d_dx, size * sizeof(float));

    cudaMemcpy(d_x,  h_x,  size * sizeof(float), cudaMemcpyHostToDevice);
    cudaMemcpy(d_dx, h_dx, size * sizeof(float), cudaMemcpyHostToDevice);

    int threads = 256;
    int blocks  = (size + threads - 1) / threads;
    relu_derivative<<<blocks, threads>>>(d_x, d_dx, size);
    cudaDeviceSynchronize();

    cudaMemcpy(h_dx, d_dx, size * sizeof(float), cudaMemcpyDeviceToHost);
    cudaFree(d_x);
    cudaFree(d_dx);
}

// ============================================================
// KERNEL-LEVEL TEST RUNNERS
// ============================================================

static bool test_bias_gradient(const char* label,
                                int N, int D,
                                float tol, unsigned int seed)
{
    printf("  [bias_gradient] %s  N=%d D=%d\n", label, N, D);

    float* dZ     = (float*)malloc(N * D * sizeof(float));
    float* cpu_db = (float*)calloc(D, sizeof(float));
    float* gpu_db = (float*)calloc(D, sizeof(float));

    fill_random(dZ, N * D, &seed);

    cpu_bias_gradient(dZ, cpu_db, N, D);
    launch_bias_gradient(dZ, gpu_db, N, D);

    cudaError_t err = cudaGetLastError();
    bool passed = (err == cudaSuccess);
    if (err != cudaSuccess) {
        printf("    CUDA error: %s  -> FAIL\n", cudaGetErrorString(err));
    } else {
        int ok = compare_arrays("db", cpu_db, gpu_db, D, tol);
        passed = ok ? true : false;
        printf("    Result: %s\n", ok ? "PASS" : "FAIL");
    }

    free(dZ); free(cpu_db); free(gpu_db);
    return passed;
}

static bool test_relu_derivative(const char* label,
                                  int size,
                                  float tol, unsigned int seed)
{
    bool passed = true;
    printf("  [relu_derivative] %s  size=%d\n", label, size);

    float* x      = (float*)malloc(size * sizeof(float));
    float* cpu_dx = (float*)malloc(size * sizeof(float));
    float* gpu_dx = (float*)malloc(size * sizeof(float));

    fill_random(x,      size, &seed);
    fill_random(cpu_dx, size, &seed);
    memcpy(gpu_dx, cpu_dx, size * sizeof(float));

    cpu_relu_derivative(x, cpu_dx, size);
    launch_relu_derivative(x, gpu_dx, size);

    cudaError_t err = cudaGetLastError();
    passed = (err == cudaSuccess);
    if (err != cudaSuccess) {
        printf("    CUDA error: %s  -> FAIL\n", cudaGetErrorString(err));
    } else {
        int ok = compare_arrays("dx", cpu_dx, gpu_dx, size, tol);
        if (!ok) passed = false;
        printf("    Result: %s\n", ok ? "PASS" : "FAIL");
    }

    free(x); free(cpu_dx); free(gpu_dx);
    return passed;
}

// ============================================================
// MAIN
// ============================================================

int main(void)
{
    srand(41);

    int passed = 0;

    printf("=== bias_gradient kernel tests ===\n");

    passed += test_bias_gradient("TC1", /*N=*/1,   /*D=*/16,  /*tol=*/1e-5f, /*seed=*/22u);
    passed += test_bias_gradient("TC2", /*N=*/128, /*D=*/1,   /*tol=*/1e-4f, /*seed=*/33u);

    printf("\n");

    printf("=== relu_derivative kernel tests ===\n");

    passed += test_relu_derivative("TC1", /*size=*/16,  /*tol=*/1e-6f, /*seed=*/222u);
    passed += test_relu_derivative("TC2", /*size=*/97,  /*tol=*/1e-5f, /*seed=*/333u);

    printf("\n");

    printf("Total Passed: %d\n", passed);
    return 0;
}
