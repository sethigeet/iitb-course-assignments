import sys
import re

START_MARKER = "// START OF STUDENT CODE"
END_MARKER   = "// END OF STUDENT CODE"

KERNEL2_NAMES = {"bias_gradient", "relu_derivative"}


def extract_block(filepath: str) -> str:
    with open(filepath, "r") as f:
        lines = f.readlines()

    inside      = False
    block       = []
    found_start = False
    found_end   = False

    for line in lines:
        if START_MARKER in line:
            inside      = True
            found_start = True
            continue          # skip the marker line itself
        if END_MARKER in line:
            found_end = True
            inside    = False
            continue          # skip the marker line itself
        if inside:
            block.append(line)

    if not found_start:
        raise ValueError(f"START marker '{START_MARKER}' not found in {filepath}")
    if not found_end:
        raise ValueError(f"END marker '{END_MARKER}' not found in {filepath}")

    return "".join(block)


def inject_block(evaluator_path: str, student_code: str) -> str:
    with open(evaluator_path, "r") as f:
        evaluator_src = f.read()

    start_idx = evaluator_src.find(START_MARKER)
    end_idx   = evaluator_src.find(END_MARKER)

    if start_idx == -1:
        raise ValueError(f"START marker not found in {evaluator_path}")
    if end_idx == -1:
        raise ValueError(f"END marker not found in {evaluator_path}")

    end_of_start_line  = evaluator_src.index("\n", start_idx) + 1
    start_of_end_line  = evaluator_src.rindex("\n", 0, end_idx) + 1

    merged = (
        evaluator_src[:end_of_start_line]       # …up to and including START line
        + "\n"
        + student_code.rstrip("\n")
        + "\n\n"
        + evaluator_src[start_of_end_line:]      # END line and everything after
    )
    return merged



def _find_function_start(lines: list[str], name: str) -> int:

    pattern = re.compile(
        r'(?:__global__|__device__|__host__)?\s*\w[\w\s\*]*\b'
        + re.escape(name)
        + r'\s*\('
    )
    for i, line in enumerate(lines):
        if re.search(r'\b' + re.escape(name) + r'\s*\(', line):
            stripped = line.strip()
            if stripped.endswith(';'):
                continue
            if stripped.endswith(');'):
                continue
            return i
    return -1


def extract_kernels_for_eval2(student_code: str, kernel_names: set) -> str:
    lines = student_code.splitlines(keepends=True)
    ranges = []   # list of (start_line_idx, end_line_idx) inclusive

    for name in kernel_names:
        start = _find_function_start(lines, name)
        if start == -1:
            print(f"  [extract_code] WARNING: kernel '{name}' not found in "
                  f"student code — it will be absent from evaluator2 output.")
            continue

    
        depth = 0
        end   = start
        found_open = False
        for i in range(start, len(lines)):
            for ch in lines[i]:
                if ch == '{':
                    depth += 1
                    found_open = True
                elif ch == '}':
                    depth -= 1
            if found_open and depth == 0:
                end = i
                break
        else:
            print(f"  [extract_code] WARNING: could not find closing brace "
                  f"for '{name}' — skipping.")
            continue

        ranges.append((start, end))

    if not ranges:
        return ""

    # Sort by start position and deduplicate overlapping ranges.
    ranges.sort()
    merged: list[tuple[int, int]] = [ranges[0]]
    for s, e in ranges[1:]:
        if s <= merged[-1][1] + 1:          # adjacent or overlapping
            merged[-1] = (merged[-1][0], max(merged[-1][1], e))
        else:
            merged.append((s, e))

    parts = []
    for s, e in merged:
        parts.append("".join(lines[s:e + 1]))

    return "\n\n".join(parts)


def main():
    if len(sys.argv) not in (4, 6):
        print(
            "Usage (single):  python3 extract_code.py "
            "<student.cu> <evaluator.cu> <output.cu>\n"
            "Usage (dual):    python3 extract_code.py "
            "<student.cu> <evaluator.cu> <output.cu> "
            "<evaluator2.cu> <output2.cu>"
        )
        sys.exit(1)

    student_path    = sys.argv[1]
    evaluator_path  = sys.argv[2]
    output_path     = sys.argv[3]
    dual_mode       = len(sys.argv) == 6
    evaluator2_path = sys.argv[4] if dual_mode else None
    output2_path    = sys.argv[5] if dual_mode else None

    print(f"[extract_code] Reading student block from : {student_path}")
    student_code = extract_block(student_path)
    print(f"[extract_code] Extracted {len(student_code.splitlines())} lines "
          f"of student code.")

    print(f"[extract_code] Injecting into evaluator   : {evaluator_path}")
    merged = inject_block(evaluator_path, student_code)
    with open(output_path, "w") as f:
        f.write(merged)
    print(f"[extract_code] Merged file written to     : {output_path}")

    if dual_mode:
        print(f"\n[extract_code] Extracting kernel-only code for evaluator2 ...")
        kernel_code = extract_kernels_for_eval2(student_code, KERNEL2_NAMES)

        if not kernel_code.strip():
            print("[extract_code] WARNING: no matching kernels found; "
                  "evaluator2 output will have an empty student section.")

        print(f"[extract_code] Kernel code: "
              f"{len(kernel_code.splitlines())} lines extracted "
              f"({', '.join(sorted(KERNEL2_NAMES))}).")

        print(f"[extract_code] Injecting into evaluator2  : {evaluator2_path}")
        merged2 = inject_block(evaluator2_path, kernel_code)
        with open(output2_path, "w") as f:
            f.write(merged2)
        print(f"[extract_code] Merged file written to     : {output2_path}")


if __name__ == "__main__":
    main()