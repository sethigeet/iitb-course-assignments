set -euo pipefail
python3 extract_code.py student.cu evaluator.cu q2_merged.cu
sed 's/float scale = sqrtf((float)D);/float scale = 1.0f \/ sqrtf((float)D);/' q2_merged.cu > q2_merged_inverse.cu