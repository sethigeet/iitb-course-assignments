import sys
import re

START_MARKER = "// START OF STUDENT CODE"
END_MARKER   = "// END OF STUDENT CODE"


def extract_block(filepath: str) -> str:
    with open(filepath, "r") as f:
        lines = f.readlines()

    inside = False
    block  = []
    found_start = False
    found_end   = False

    for line in lines:
        if START_MARKER in line:
            inside      = True
            found_start = True
            continue         
        if END_MARKER in line:
            found_end = True
            inside    = False
            continue      
        if inside:
            block.append(line)

    if not found_start:
        raise ValueError(f"START marker '{START_MARKER}' not found in {filepath}")
    if not found_end:
        raise ValueError(f"END marker '{END_MARKER}' not found in {filepath}")

    return "".join(block)


def inject_block(evaluator_path: str, student_code: str) -> str:
    with open(evaluator_path, "r") as f:
        evaluator_src = f.read()

    pattern = re.compile(
        r"(// =+\n)?// START OF STUDENT CODE.*?// END OF STUDENT CODE(\n// =+)?",
        re.DOTALL
    )

    start_idx = evaluator_src.find(START_MARKER)
    end_idx   = evaluator_src.find(END_MARKER)

    if start_idx == -1:
        raise ValueError(f"START marker not found in {evaluator_path}")
    if end_idx == -1:
        raise ValueError(f"END marker not found in {evaluator_path}")

    end_of_start_line = evaluator_src.index("\n", start_idx) + 1
    start_of_end_line = evaluator_src.rindex("\n", 0, end_idx) + 1 

    merged = (
        evaluator_src[:end_of_start_line]        
        + "\n"
        + student_code.rstrip("\n")
        + "\n\n"
        + evaluator_src[start_of_end_line:]        
    )
    return merged


def main():
    if len(sys.argv) != 4:
        print("Usage: python3 extract_code.py <student.cu> <evaluator.cu> <output.cu>")
        sys.exit(1)

    student_path   = sys.argv[1]
    evaluator_path = sys.argv[2]
    output_path    = sys.argv[3]

    print(f"[extract_code] Reading student block from : {student_path}")
    student_code = extract_block(student_path)
    print(f"[extract_code] Extracted {len(student_code.splitlines())} lines of student code.")

    print(f"[extract_code] Injecting into evaluator   : {evaluator_path}")
    merged = inject_block(evaluator_path, student_code)

    with open(output_path, "w") as f:
        f.write(merged)

    print(f"[extract_code] Merged file written to     : {output_path}")


if __name__ == "__main__":
    main()
