#include <cuda_runtime.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "student_kernels.cuh"


#define MAX_NAME   128
#define MAX_ELEMS 4096
#define MAX_CASES   64

typedef struct {
    char  name[MAX_NAME];
    int   height, width, kernel_size;
    int   out_height, out_width;
    float input        [MAX_ELEMS];
    float kernel_f     [MAX_ELEMS];
    float expected_conv[MAX_ELEMS];
    float relu_input   [MAX_ELEMS];  
    float expected_relu[MAX_ELEMS];
    int   input_len, kernel_len, conv_len, relu_in_len, relu_len;
} TestCase;

static const char* skip_ws(const char* p) {
    while (*p==' '||*p=='\t'||*p=='\n'||*p=='\r') p++; return p;
}
static const char* expect_char(const char* p, char c) {
    p = skip_ws(p);
    if (*p != c) { fprintf(stderr,"JSON: expected '%c' got '%c'\n",c,*p); exit(2); }
    return p+1;
}
static const char* read_string(const char* p, char* buf, int sz) {
    p = expect_char(p,'"'); int i=0;
    while (*p && *p!='"') { if(i<sz-1) buf[i++]=*p; p++; }
    buf[i]='\0'; return p+1;
}
static const char* read_int(const char* p, int* out) {
    p=skip_ws(p); int s=1; if(*p=='-'){s=-1;p++;} int v=0;
    while(*p>='0'&&*p<='9'){v=v*10+(*p-'0');p++;} *out=s*v; return p;
}
static const char* read_float(const char* p, float* out) {
    p=skip_ws(p); char t[64]; int i=0;
    while((*p>='0'&&*p<='9')||*p=='-'||*p=='.'||*p=='e'||*p=='E'||*p=='+')
        { if(i<63)t[i++]=*p; p++; }
    t[i]='\0'; *out=(float)atof(t); return p;
}
static const char* read_float_array(const char* p, float* arr, int* cnt) {
    p=expect_char(p,'['); *cnt=0; p=skip_ws(p);
    if(*p==']') return p+1;
    while(1){ p=skip_ws(p); p=read_float(p,&arr[(*cnt)++]); p=skip_ws(p);
              if(*p==']'){p++;break;} p=expect_char(p,','); }
    return p;
}
static const char* find_key(const char* p, const char* key) {
    char buf[MAX_NAME];
    while(*p){ if(*p=='"'){ const char* q=read_string(p,buf,sizeof(buf));
        q=skip_ws(q); if(*q==':'&&strcmp(buf,key)==0) return q+1; p=q; }
        else p++; }
    fprintf(stderr,"JSON: key '%s' not found\n",key); exit(2);
}
static void parse_case(const char* s, const char* e, TestCase* tc) {
    size_t len=(size_t)(e-s); char* buf=(char*)malloc(len+1);
    memcpy(buf,s,len); buf[len]='\0'; const char* p;
    p=find_key(buf,"name");        read_string(skip_ws(p),tc->name,MAX_NAME);
    p=find_key(buf,"height");      read_int(p,&tc->height);
    p=find_key(buf,"width");       read_int(p,&tc->width);
    p=find_key(buf,"kernel_size"); read_int(p,&tc->kernel_size);
    p=find_key(buf,"out_height");  read_int(p,&tc->out_height);
    p=find_key(buf,"out_width");   read_int(p,&tc->out_width);
    p=find_key(buf,"input");       read_float_array(skip_ws(p),tc->input,        &tc->input_len);
    p=find_key(buf,"kernel");      read_float_array(skip_ws(p),tc->kernel_f,     &tc->kernel_len);
    p=find_key(buf,"expected_conv");read_float_array(skip_ws(p),tc->expected_conv,&tc->conv_len);
    p=find_key(buf,"relu_input");  read_float_array(skip_ws(p),tc->relu_input,   &tc->relu_in_len);
    p=find_key(buf,"expected_relu");read_float_array(skip_ws(p),tc->expected_relu,&tc->relu_len);
    free(buf);
}
static int load_cases(const char* path, TestCase* cases, int max) {
    FILE* f=fopen(path,"r"); if(!f){perror(path);exit(2);}
    fseek(f,0,SEEK_END); long sz=ftell(f); rewind(f);
    char* raw=(char*)malloc(sz+1); fread(raw,1,sz,f); fclose(f); raw[sz]='\0';
    int cnt=0; const char* p=raw;
    while(*p&&*p!='[') p++; p++;
    while(*p&&cnt<max){
        p=skip_ws(p); if(*p==']') break; if(*p==','){p++;continue;}
        if(*p!='{'){p++;continue;}
        const char* s=p+1; int d=1; const char* q=p+1;
        while(*q&&d>0){if(*q=='{')d++;else if(*q=='}')d--;q++;}
        parse_case(s,q-1,&cases[cnt++]); p=q;
    }
    free(raw); return cnt;
}

/* ── CUDA helpers ───────────────────────────────────────────────────────── */

#define EPSILON 1e-3f
#define CUDA_CHECK(call) do { cudaError_t _e=(call); \
    if(_e!=cudaSuccess){fprintf(stderr,"CUDA %s:%d %s\n",__FILE__,__LINE__, \
    cudaGetErrorString(_e));exit(3);} } while(0)

typedef struct {
    bool  conv_pass, relu_pass;
    int   conv_wrong, relu_wrong;
    float conv_max_err, relu_max_err;
} CaseResult;

static CaseResult evaluate_case(const TestCase* tc) {
    CaseResult r = {true,true,0,0,0.0f,0.0f};
    int in_elems  = tc->height * tc->width;
    int ker_elems = tc->kernel_size * tc->kernel_size;
    int out_elems = tc->out_height * tc->out_width;

    /* ── CONV: independent inputs ─────────────────────────────────────── */
    {
        float *d_in, *d_ker, *d_out;
        CUDA_CHECK(cudaMalloc(&d_in,  in_elems  * sizeof(float)));
        CUDA_CHECK(cudaMalloc(&d_ker, ker_elems * sizeof(float)));
        CUDA_CHECK(cudaMalloc(&d_out, out_elems * sizeof(float)));
        CUDA_CHECK(cudaMemset(d_out, 0, out_elems * sizeof(float)));
        CUDA_CHECK(cudaMemcpy(d_in,  tc->input,    in_elems *sizeof(float), cudaMemcpyHostToDevice));
        CUDA_CHECK(cudaMemcpy(d_ker, tc->kernel_f, ker_elems*sizeof(float), cudaMemcpyHostToDevice));

        dim3 block(16,16);
        dim3 grid((tc->out_width +block.x-1)/block.x,
                  (tc->out_height+block.y-1)/block.y);
        conv2d_kernel<<<grid,block>>>(d_in,d_ker,d_out,
                                      tc->height,tc->width,tc->kernel_size);
        CUDA_CHECK(cudaDeviceSynchronize());

        float* h_out = (float*)malloc(out_elems*sizeof(float));
        CUDA_CHECK(cudaMemcpy(h_out,d_out,out_elems*sizeof(float),cudaMemcpyDeviceToHost));

        for(int i=0;i<out_elems;i++){
            float err=fabsf(h_out[i]-tc->expected_conv[i]);
            if(err>r.conv_max_err) r.conv_max_err=err;
            if(err>EPSILON){r.conv_wrong++;r.conv_pass=false;}
        }
        cudaFree(d_in); cudaFree(d_ker); cudaFree(d_out); free(h_out);
    }

    /* ── RELU: uses relu_input — completely independent of conv ───────── */
    {
        float* d_data;
        CUDA_CHECK(cudaMalloc(&d_data, out_elems*sizeof(float)));
        CUDA_CHECK(cudaMemcpy(d_data, tc->relu_input,
                              out_elems*sizeof(float), cudaMemcpyHostToDevice));

        int tpb=256, bpg=(out_elems+tpb-1)/tpb;
        relu_kernel<<<bpg,tpb>>>(d_data, out_elems);
        CUDA_CHECK(cudaDeviceSynchronize());

        float* h_out=(float*)malloc(out_elems*sizeof(float));
        CUDA_CHECK(cudaMemcpy(h_out,d_data,out_elems*sizeof(float),cudaMemcpyDeviceToHost));

        for(int i=0;i<out_elems;i++){
            float err=fabsf(h_out[i]-tc->expected_relu[i]);
            if(err>r.relu_max_err) r.relu_max_err=err;
            if(err>EPSILON){r.relu_wrong++;r.relu_pass=false;}
        }
        cudaFree(d_data); free(h_out);
    }

    return r;
}

/* ── main ───────────────────────────────────────────────────────────────── */

int main(int argc, char** argv) {
    const char* json_path = (argc>1) ? argv[1] : "testcases.json";
    static TestCase cases[MAX_CASES];
    int n = load_cases(json_path, cases, MAX_CASES);

    printf("Loaded %d test cases from %s\n\n", n, json_path);

    printf("%-42s %-20s %-20s\n", "Test Case","conv2d_kernel","relu_kernel");
    printf("%-42s %-20s %-20s\n",
           "------------------------------------------",
           "--------------------","--------------------");

    int conv_pass_total=0, relu_pass_total=0;

    for(int i=0;i<n;i++){
        CaseResult r = evaluate_case(&cases[i]);
        if(r.conv_pass) conv_pass_total++;
        if(r.relu_pass) relu_pass_total++;

        char cs[32], rs[32];
        if(r.conv_pass) snprintf(cs,sizeof(cs),"PASS");
        else            snprintf(cs,sizeof(cs),"FAIL (%d, e=%.1e)",r.conv_wrong,r.conv_max_err);
        if(r.relu_pass) snprintf(rs,sizeof(rs),"PASS");
        else            snprintf(rs,sizeof(rs),"FAIL (%d, e=%.1e)",r.relu_wrong,r.relu_max_err);

        printf("%-42s %-20s %-20s\n", cases[i].name, cs, rs);
    }

    int total_possible = n*2;
    int total_scored   = conv_pass_total + relu_pass_total;

    printf("\n");
    printf("==========================================================\n");
    printf("  conv2d_kernel : %d / %d\n", conv_pass_total, n);
    printf("  relu_kernel   : %d / %d\n", relu_pass_total, n);
    printf("==========================================================\n");

    return (total_scored == total_possible) ? 0 : 1;
}