import sys
import re
import os

KERNEL_NAMES = ["conv2d_kernel", "relu_kernel"]

def extract_kernel(source: str, kernel_name: str) -> str | None:
    name_match = re.search(r'\b' + re.escape(kernel_name) + r'\b', source)
    if name_match is None:
        return None

    pos = name_match.start()

    prefix = source[:pos]
    global_match = list(re.finditer(r'__global__\s+void\s*$', prefix.rstrip()))

    if not global_match:
        global_match = list(re.finditer(r'__global__', prefix))
        if not global_match:
            return None
    
    start_pos = global_match[-1].start()

    search_from = pos
    brace_pos = source.find('{', search_from)
    if brace_pos == -1:
        return None

    depth = 0
    i = brace_pos
    while i < len(source):
        if source[i] == '{':
            depth += 1
        elif source[i] == '}':
            depth -= 1
            if depth == 0:
                end_pos = i + 1
                return source[start_pos:end_pos]
        i += 1

    return None  


def build_output(kernels: dict[str, str], original_filename: str) -> str:
    guard = "STUDENT_KERNELS_CUH"
    lines = [
        f"// Auto-extracted from: {original_filename}",
        f"// Kernels: {', '.join(kernels.keys())}",
        "",
        f"#ifndef {guard}",
        f"#define {guard}",
        "",
        "#include <cuda_runtime.h>",
        "",
    ]
    for name, body in kernels.items():
        lines.append(f"// ── {name} " + "─" * (60 - len(name)))
        lines.append(body.strip())
        lines.append("")
    lines += [f"#endif // {guard}", ""]
    return "\n".join(lines)


def main():
    if len(sys.argv) < 2:
        print("Usage: python extract_kernels.py <student_file> [output_file]",
              file=sys.stderr)
        sys.exit(2)

    student_file = sys.argv[1]
    output_file  = sys.argv[2] if len(sys.argv) > 2 else "student_kernels.cuh"

    try:
        with open(student_file, "r", errors="replace") as f:
            source = f.read()
    except OSError as e:
        print(f"ERROR: Cannot read '{student_file}': {e}", file=sys.stderr)
        sys.exit(2)

    found   = {}
    missing = []

    for name in KERNEL_NAMES:
        body = extract_kernel(source, name)
        if body:
            found[name] = body
            print(f"  [FOUND]   {name}  ({len(body)} chars)")
        else:
            missing.append(name)
            print(f"  [MISSING] {name}", file=sys.stderr)

    if missing:
        print(f"\nExtraction FAILED: missing kernel(s): {', '.join(missing)}",
              file=sys.stderr)
        sys.exit(1)

    output = build_output(found, os.path.basename(student_file))

    try:
        with open(output_file, "w") as f:
            f.write(output)
    except OSError as e:
        print(f"ERROR: Cannot write '{output_file}': {e}", file=sys.stderr)
        sys.exit(2)

    print(f"\nExtracted kernels written to: {output_file}")
    sys.exit(0)


if __name__ == "__main__":
    main()
