set -euo pipefail

STUDENT_FILE="student.cu"
JSON_FILE="testcases.json"

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
EVAL_SRC="$SCRIPT_DIR/evaluator.cu"
EXTRACTED="$SCRIPT_DIR/student_kernels.cuh" 
EVAL_BIN="$SCRIPT_DIR/evaluator_bin"
EXTRACTOR="$SCRIPT_DIR/extract_kernels.py"

# ── colour helpers ─────────────────────────────────────────────────────────
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'
ok()   { echo -e "${GREEN}[OK]${NC}  $*"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $*"; }
err()  { echo -e "${RED}[ERR]${NC} $*" >&2; }

echo "=================================================="
echo "  CUDA Kernel Evaluator"
echo "  Student file : $STUDENT_FILE"
echo "  Test cases   : $JSON_FILE"
echo "=================================================="

# ── 1. Pre-flight checks ───────────────────────────────────────────────────
for f in "$STUDENT_FILE" "$JSON_FILE" "$EVAL_SRC" "$EXTRACTOR"; do
    if [[ ! -f "$f" ]]; then
        err "Required file not found: $f"
        exit 2
    fi
done

# ── 2. Extract kernels from the student's full submission ──────────────────
echo ""
echo "Extracting kernel functions from student submission..."

EXTRACT_LOG=$(mktemp)
if python3 "$EXTRACTOR" "$STUDENT_FILE" "$EXTRACTED" 2>&1 | tee "$EXTRACT_LOG"; then
    ok "Kernel extraction succeeded → $EXTRACTED"
else
    EXTRACT_EXIT=${PIPESTATUS[0]}
    err "Kernel extraction FAILED (exit $EXTRACT_EXIT). See output above."
    rm -f "$EXTRACT_LOG"
    exit 11
fi
rm -f "$EXTRACT_LOG"

# ── 3. Compile ─────────────────────────────────────────────────────────────
echo ""
echo "Compiling evaluator..."

COMPILE_LOG=$(mktemp)
if nvcc -ccbin=/usr/bin/gcc-11 -std=c++17 -O2 -lcudart -lstdc++ -lnvToolsExt \
        -o "$EVAL_BIN" "$EVAL_SRC" \
        -I"$SCRIPT_DIR" \
        2>"$COMPILE_LOG"; then
    ok "Compilation succeeded."
else
    err "Compilation FAILED. Compiler output:"
    cat "$COMPILE_LOG" >&2
    rm -f "$COMPILE_LOG"
    exit 10
fi
rm -f "$COMPILE_LOG"

# ── 4. Run evaluation ──────────────────────────────────────────────────────
echo ""
echo "Running evaluation..."
echo "--------------------------------------------------"

set +e
"$EVAL_BIN" "$JSON_FILE"
EVAL_EXIT=$?
set -e

echo "--------------------------------------------------"

case $EVAL_EXIT in
    0) ok "All tests passed!" ;;
    1) warn "Some tests failed. See results above." ;;
    *) err "Evaluator exited with unexpected code $EVAL_EXIT" ;;
esac

# ── 5. Cleanup ─────────────────────────────────────────────────────────────
rm -f "$EVAL_BIN" "$EXTRACTED"

exit $EVAL_EXIT
