#!/usr/bin/env bash
set -euo pipefail

SRC="student.cu"
HEADER="transpose_impl.cuh"
EVAL_SRC="evaluator.cu"
EVAL_BIN="eval_transpose"

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo " Step 1: Extract kernel + wrapper"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
python3 extract_kernels.py "$SRC" "$HEADER"

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo " Step 2: Compile eval harness"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
nvcc -O2 -lineinfo -ccbin=/usr/bin/gcc-11 -std=c++17 -lcudart -lstdc++ -lnvToolsExt -o "$EVAL_BIN" "$EVAL_SRC" -lm
echo "Compiled → $EVAL_BIN"

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo " Step 3: Run evaluation"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
./"$EVAL_BIN"

rm -rf "$EVAL_BIN" "$HEADER"
