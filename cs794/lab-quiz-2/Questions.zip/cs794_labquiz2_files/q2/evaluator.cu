#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <cuda_runtime.h>
#include "transpose_impl.cuh"

static const int TEST_SIZES[] = {
    13,
    31,
    64,
    128,
    138,
    511,
    512,
    517,
    1024,
    16384
};
static const int NUM_TESTS = (int)(sizeof(TEST_SIZES) / sizeof(TEST_SIZES[0]));

#define WARMUP_RUNS  3
#define TIMED_RUNS   10

static void fill_random(int m, float *a)
{
    for (int i = 0; i < m * m; i++)
        a[i] = (float)(rand() % 1000) / 100.0f;
}

static void cpu_transpose(int m, const float *a, float *c)
{
    for (int r = 0; r < m; r++)
        for (int col = 0; col < m; col++)
            c[INDX(col, r, m)] = a[INDX(r, col, m)];
}

static int compare(int m, const float *ref, const float *tst, float tol)
{
    for (int i = 0; i < m * m; i++)
        if (fabsf(ref[i] - tst[i]) > tol) {
            printf("  MISMATCH at [%d]: ref=%.5f  gpu=%.5f\n",
                   i, ref[i], tst[i]);
            return 0;
        }
    return 1;
}

static double now_sec(void)
{
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec + ts.tv_nsec * 1e-9;
}

int main(void)
{
    srand(42);
    printf("Correctness tests\n");
    printf("─────────────────────────────────────────────────────\n");

    int passed = 0;

    for (int t = 0; t < NUM_TESTS; t++) {
        int m = TEST_SIZES[t];
        printf("  [%5d x %5d]  ", m, m);
        fflush(stdout);

        size_t bytes = (size_t)m * m * sizeof(float);
        float *h_a   = (float*)malloc(bytes);
        float *h_ref = (float*)malloc(bytes);
        float *h_gpu = (float*)malloc(bytes);

        fill_random(m, h_a);
        cpu_transpose(m, h_a, h_ref);
        gpu_transpose(m, h_a, h_gpu);

        cudaError_t err = cudaGetLastError();
        if (err != cudaSuccess) {
            printf("CUDA ERROR: %s\n", cudaGetErrorString(err));
        } 
        else {
            int ok = compare(m, h_ref, h_gpu, 1e-4f);
            printf("%s\n", ok ? "PASS" : "FAIL");
            if (ok) passed++;
        }
        free(h_a); free(h_ref); free(h_gpu);
    }

    /* ── Timing ─────────────────────────────────────────────── */
    int m = TEST_SIZES[NUM_TESTS - 1];
    printf("  Timing run  —  %d x %d matrix\n", m, m);
    printf("  Warm-up calls : %d\n", WARMUP_RUNS);
    printf("  Timed   calls : %d\n", TIMED_RUNS);

    size_t bytes = (size_t)m * m * sizeof(float);
    float *h_a = (float*)malloc(bytes);
    float *h_c = (float*)malloc(bytes);
    fill_random(m, h_a);

    for (int i = 0; i < WARMUP_RUNS; i++)
        gpu_transpose(m, h_a, h_c);
    cudaDeviceSynchronize();

    double wall_start = now_sec();
    for (int i = 0; i < TIMED_RUNS; i++)
        gpu_transpose(m, h_a, h_c);
    cudaDeviceSynchronize();
    double wall_elapsed = now_sec() - wall_start;
    double avg_ms = (wall_elapsed / TIMED_RUNS) * 1e3;

    free(h_a);
    free(h_c);

    printf("\nDone.\n");

    printf("Testcases passed: %d / %d\n", passed, NUM_TESTS);
    printf("Average time per timed run: %.4f ms\n", avg_ms);

    return 0;
}