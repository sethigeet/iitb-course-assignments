#!/usr/bin/env bash
set -euo pipefail

SRC="${1:-student.cu}"
HEADER="matmul_kernel.cuh"
EVAL_SRC="evaluator.cu"
EVAL_BIN="eval_matmul"

banner() { echo ""; echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"; echo "  $*"; echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"; }

if [[ ! -f "$SRC" ]]; then
    echo "ERROR: source file '$SRC' not found." >&2
    echo "Usage: $0 <student_source.cu>" >&2
    exit 2
fi

for cmd in python3 nvcc; do
    if ! command -v "$cmd" &>/dev/null; then
        echo "ERROR: '$cmd' not found in PATH." >&2
        exit 2
    fi
done

banner "Step 1: Extract kernel + launcher  [$SRC → $HEADER]"
python3 extract_kernels.py "$SRC" "$HEADER"

banner "Step 2: Compile evaluator  [$EVAL_SRC → $EVAL_BIN]"
nvcc -O2 -lineinfo -ccbin=/usr/bin/gcc-11 -std=c++17 -O2 -lcudart -lstdc++ -lnvToolsExt \
     -lineinfo \
     -o "$EVAL_BIN" "$EVAL_SRC" \
     -lm
echo "  Compiled → $EVAL_BIN"

banner "Step 3: Run evaluation"
./"$EVAL_BIN"
EXIT_CODE=$?

echo ""
if [[ $EXIT_CODE -eq 0 ]]; then
    echo "  ✓ All correctness tests passed."
else
    echo "  ✗ Some correctness tests FAILED (exit code $EXIT_CODE)." >&2
fi

rm -rf "$HEADER" "$EVAL_BIN"

exit $EXIT_CODE 
