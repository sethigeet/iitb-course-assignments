#include <iostream>
#include <vector>
#include <cmath>
#include <chrono>

// ── Extracted kernel (matmul_tiled_block2d_kernel only) ──────────────────────
#include "matmul_kernel.cuh"


// ─────────────────────────────────────────────────────────────────────────────
// GPU launcher — lives here, not extracted into the header
// ─────────────────────────────────────────────────────────────────────────────

/**
 * @brief Launch GPU block-tiling matrix multiplication.
 *
 * @tparam R Register tile size per thread.
 *
 * @param N      Matrix dimension (NxN)
 * @param TILE   Shared-memory tile dimension
 * @param A_h    Host pointer to matrix A
 * @param B_h    Host pointer to matrix B
 * @param C_h    Host pointer to matrix C (output)
 */
template<int R>
void matmul_gpu_block2d(int N,
                        int TILE,
                        const float* A_h,
                        const float* B_h,
                        float* C_h)
{
    size_t bytes = (size_t)N * N * sizeof(float);

    float *A_d, *B_d, *C_d;
    cudaMalloc(&A_d, bytes);
    cudaMalloc(&B_d, bytes);
    cudaMalloc(&C_d, bytes);

    cudaMemcpy(A_d, A_h, bytes, cudaMemcpyHostToDevice);
    cudaMemcpy(B_d, B_h, bytes, cudaMemcpyHostToDevice);

    /// Each thread computes R x R results
    dim3 block(TILE / R, TILE / R);
    dim3 grid((N + TILE - 1) / TILE,
              (N + TILE - 1) / TILE);

    size_t sharedBytes = 2 * TILE * TILE * sizeof(float);

    matmul_tiled_block2d_kernel<R>
        <<<grid, block, sharedBytes>>>(A_d, B_d, C_d, N, TILE);

    cudaMemcpy(C_h, C_d, bytes, cudaMemcpyDeviceToHost);

    cudaFree(A_d);
    cudaFree(B_d);
    cudaFree(C_d);
}


// ─────────────────────────────────────────────────────────────────────────────
// CPU reference
// ─────────────────────────────────────────────────────────────────────────────
static void matmul_cpu(int N, const float* A, const float* B, float* C)
{
    for (int i = 0; i < N; i++)
        for (int j = 0; j < N; j++) {
            float s = 0.f;
            for (int k = 0; k < N; k++)
                s += A[i*N+k] * B[k*N+j];
            C[i*N+j] = s;
        }
}

// ─────────────────────────────────────────────────────────────────────────────
// Element-wise verifier
// ─────────────────────────────────────────────────────────────────────────────
static bool verify(int N, const float* ref, const float* gpu, float tol = 1e-2f)
{
    for (int i = 0; i < N*N; i++) {
        if (std::fabs(ref[i] - gpu[i]) > tol) {
            std::cout << "  ✗ mismatch at [" << i/N << "][" << i%N << "]"
                      << "  ref=" << ref[i] << "  gpu=" << gpu[i] << "\n";
            return false;
        }
    }
    return true;
}

// ─────────────────────────────────────────────────────────────────────────────
// Single correctness test
// ─────────────────────────────────────────────────────────────────────────────
template<int R>
bool run_test(int id, int N, int TILE)
{
    std::cout << "  Test " << id
              << "  N=" << N << "  TILE=" << TILE << "  R=" << R
              << " ... " << std::flush;

    std::vector<float> A(N*N), B(N*N), C_cpu(N*N,0.f), C_gpu(N*N,0.f);

    for (int i = 0; i < N*N; i++) {
        A[i] = float(i % 97);
        B[i] = float((i * 13) % 97);
    }

    matmul_cpu(N, A.data(), B.data(), C_cpu.data());
    matmul_gpu_block2d<R>(N, TILE, A.data(), B.data(), C_gpu.data());

    bool ok = verify(N, C_cpu.data(), C_gpu.data());
    std::cout << (ok ? "PASSED ✓" : "FAILED ✗") << "\n";
    return ok;
}

// ─────────────────────────────────────────────────────────────────────────────
// Main
// ─────────────────────────────────────────────────────────────────────────────
int main()
{
    std::cout << "\n"
              << "║      Matrix-Multiplication Evaluator     ║\n";

    std::cout << "── Correctness tests ──────────────────────────────────────\n";

    int passed = 0;
    passed += run_test<1>( 1,  64,  8);
    passed += run_test<2>( 2,  64, 16);
    passed += run_test<4>( 3,  64, 16);
    passed += run_test<1>( 4, 128, 16);
    passed += run_test<2>( 5, 128, 16);
    passed += run_test<2>( 6, 128, 32);
    passed += run_test<4>( 7, 128, 32);
    passed += run_test<2>( 8, 256, 32);
    passed += run_test<4>( 9, 256, 32);
    passed += run_test<4>(10, 512, 32);

    std::cout << "\n  Result: " << passed << " / 10 passed\n";

    // ─── Test 11: large benchmark — timing only ───────────────────────────
    constexpr int  BN    = 16384;
    constexpr int  BTILE = 32;
    constexpr int  BR    = 4;

    std::cout << "\n── Benchmark (timing only, no correctness check) ──────────\n";
    std::cout << "  Test 11  N=" << BN
              << "  TILE=" << BTILE << "  R=" << BR << "\n";

    {
        size_t sz = (size_t)BN * BN;
        std::vector<float> A(sz), B(sz), C(sz, 0.f);
        for (size_t i = 0; i < sz; i++) {
            A[i] = float(i % 97);
            B[i] = float((i * 13) % 97);
        }

        // Warm-up
        matmul_gpu_block2d<BR>(BN, BTILE, A.data(), B.data(), C.data());

        // Timed run
        auto t0 = std::chrono::high_resolution_clock::now();
        matmul_gpu_block2d<BR>(BN, BTILE, A.data(), B.data(), C.data());
        auto t1 = std::chrono::high_resolution_clock::now();

        double ms = std::chrono::duration<double, std::milli>(t1 - t0).count();
        std::cout << "  Time (N=" << BN << ", TILE=" << BTILE << ", R=" << BR << "): " << ms << " ms\n";
    }

    // ─── Summary ─────────────────────────────────────────────────────────
    std::cout << "Correctness : " << passed << " / 10 passed\n";

    return (passed == 10) ? 0 : 1;
}
