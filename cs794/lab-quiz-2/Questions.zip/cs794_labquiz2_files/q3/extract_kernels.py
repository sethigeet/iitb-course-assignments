import sys
import re
import os

# __global__ kernels
KERNEL_NAMES = ["matmul_tiled_block2d_kernel"]


def extract_braced_body(source: str, name: str, preamble_pattern: str) -> str | None:
    name_match = re.search(r'\b' + re.escape(name) + r'\b', source)
    if name_match is None:
        return None

    pos    = name_match.start()
    prefix = source[:pos]

    candidates = list(re.finditer(preamble_pattern, prefix))
    if not candidates:
        return None

    start_pos = candidates[-1].start()

    brace_pos = source.find('{', pos)
    if brace_pos == -1:
        return None

    depth = 0
    i     = brace_pos
    while i < len(source):
        if source[i] == '{':
            depth += 1
        elif source[i] == '}':
            depth -= 1
            if depth == 0:
                return source[start_pos : i + 1]
        i += 1

    return None  # unmatched braces


def extract_kernel(source: str, kernel_name: str) -> str | None:
    preamble = r'(?:template\s*<[^>]*>\s*)?__global__'
    return extract_braced_body(source, kernel_name, preamble)


def build_header(kernels: dict[str, str], original_filename: str) -> str:

    guard = re.sub(r'[^A-Z0-9]', '_', original_filename.upper())
    guard = guard.strip('_') + '_'

    lines = [
        f"// Auto-extracted from: {original_filename}",
        f"// Kernels  : {', '.join(kernels.keys()) or '(none)'}",
        "// Note     : launcher (matmul_gpu_block2d) is defined in the evaluator.",
        "",
        f"#ifndef {guard}",
        f"#define {guard}",
        "",
        "#include <cuda_runtime.h>",
        "",
    ]

    for name, body in kernels.items():
        sep = "─" * max(2, 60 - len(name))
        lines.append(f"// ── {name} {sep}")
        lines.append(body.strip())
        lines.append("")

    lines += [f"#endif // {guard}", ""]
    return "\n".join(lines)



def main():
    if len(sys.argv) < 2:
        print("Usage: python3 extract_kernels.py <source.cu> [output.cuh]",
              file=sys.stderr)
        sys.exit(2)

    source_file = sys.argv[1]
    output_file = sys.argv[2] if len(sys.argv) > 2 else "extracted_kernels.cuh"

    try:
        with open(source_file, "r", errors="replace") as f:
            source = f.read()
    except OSError as e:
        print(f"ERROR: Cannot read '{source_file}': {e}", file=sys.stderr)
        sys.exit(2)

    print(f"Source : {source_file}  ({len(source)} chars)\n")

    found_kernels: dict[str, str] = {}
    missing: list[str] = []

    for name in KERNEL_NAMES:
        body = extract_kernel(source, name)
        if body:
            found_kernels[name] = body
            print(f"  [FOUND kernel  ]  {name}  ({len(body)} chars)")
        else:
            missing.append(name)
            print(f"  [MISSING kernel]  {name}", file=sys.stderr)

    if missing:
        print(f"\nExtraction FAILED — missing: {', '.join(missing)}",
              file=sys.stderr)
        sys.exit(1)

    header = build_header(found_kernels, os.path.basename(source_file))

    try:
        with open(output_file, "w") as f:
            f.write(header)
    except OSError as e:
        print(f"ERROR: Cannot write '{output_file}': {e}", file=sys.stderr)
        sys.exit(2)

    print(f"\nHeader written → {output_file}")
    sys.exit(0)


if __name__ == "__main__":
    main()